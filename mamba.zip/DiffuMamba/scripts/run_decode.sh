python -u run_decode.py \
--model_dir /mnt/DiffuMamba/diffusion_models/diffuseq_qqp_h128_lr0.0001_t2000_sqrt_uniform_seed102_qqp20240507-22:32:18 \
--seed 123 \
--split test